<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset='utf-8'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="styles.css">
    <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
    <script src="script.js"></script>
    <title>Joao</title>
    <style>
        article,
        h1,
        h3,
        .presentation {
            padding: 15px;
        }

        <style>body,
        html {
            height: 100%;
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
        }

        .header-img {
            width: 100%;
            height: 400px;
            background: url('http://www.kodhus.com/freecourse-images/header-image.jpg');
            background-size: cover;
        }

        .hero-text {
            text-align: center;
            position: absolute;
            top: 30%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: white;
        }

        .hero-text button {
            border: none;
            outline: 0;
            display: inline-block;
            padding: 10px 25px;
            color: black;
            background-color: #ddd;
            text-align: center;
            cursor: pointer;
        }

        .hero-text button:hover {
            background-color: #555;
            color: white;
        }
    </style>

</head>
<?php require('navbar.php') ?>
<?php require('header.php') ?>


<body>

    <h3>Most sold:</h3>
    <?php
    require_once 'database.php';
    $conn = mysqli_connect(DB_SERVER, DB_USER, DB_PASSWORD, DB_NAME);


    $db_found = mysqli_select_db($conn, DB_NAME);
    $query = 'SELECT * FROM items ORDER BY soldNum DESC LIMIT 3';
    $result = mysqli_query($conn, $query);

    while ($db_record = mysqli_fetch_assoc($result)) {
        echo '<article>';
        ?>
        <p><strong>TITLE :</strong> <a href='product.php?itemId=<?php echo $db_record['item_id'] ?>'><?php echo $db_record['title'] ?></p></a>

        <?php
        echo 'RELEASE DATE : ' . $db_record['release_date'] . '<br>';
        echo 'SELLERS NUM : <strong>' . $db_record['soldNum'] . '</strong><br>';
        echo '</article>';
        echo '<hr>';
    }

    ?>
</body>

</html>