<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset='utf-8'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="styles.css">
    <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
    <script src="script.js"></script>
    <title>Joao</title>
    <style>
        .form {
            display: flex;
            align-items: center;
            flex-direction: column;
            height: 100vh;
        }

        h1 {
            margin-bottom: 100px;
        }

        .header-img {
            width: 100%;
            height: 400px;
            background: url('http://www.kodhus.com/freecourse-images/header-image.jpg');
            background-size: cover;
        }

        .hero-text {
            text-align: center;
            position: absolute;
            top: 30%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: white;
        }

        .hero-text button {
            border: none;
            outline: 0;
            display: inline-block;
            padding: 10px 25px;
            color: black;
            background-color: #ddd;
            text-align: center;
            cursor: pointer;
        }

        .hero-text button:hover {
            background-color: #555;
            color: white;
        }
    </style>
</head>

<body>
    <?php require('navbar.php') ?>
    <?php require('header.php') ?>

    
    <section class="form">
        <h1>LOGIN</h1>

        <?php
        if (!isset($_SESSION['userId'])) {

            ?>

            <form action="" method='POST'>

                <input type="email" name='email' placeholder="Enter your email...">
                <input type="password" name='password' placeholder="Enter your password...">
                <input type="submit" name=login value='Log In'>

            </form>

        <?php
        } else {
            echo "<h1>You are logged in, do you wish to log out?</h1>";
            ?>

            <form action="" method='POST'>

                <input type="submit" name=logout value='Log out'>

            </form>
        <?php
        }

        ?>
    </section>
</body>

</html>
<?php

include_once('database.php');

if (isset($_POST['login'])) {

    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);

    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $password = htmlspecialchars($_POST['password']);

        $connection = mysqli_connect(DB_SERVER, DB_USER, DB_PASSWORD);

        $db_found = mysqli_select_db($connection, DB_NAME);

        $query = "SELECT * FROM users WHERE email = '$email'";
        $result = mysqli_query($connection, $query);

        while ($row = mysqli_fetch_assoc($result)) {
            if (password_verify($password, $row['password']) && $email === $row['email']) {
                $_SESSION['userId'] = $row['user_id'];
                echo "<p>Sucessfully connected</p>";
                header('Location: index.php');
            } else {
                echo "<p style='color: red'>Invalid password or email</p>";
            }
        }
    }
}

if (isset($_POST['logout'])) {
    session_destroy();
    header("Location: login.php");
}
