<main>
    <div class="header-img">
        <div class="hero-text">
            <h1 style="font-size:50px">Best place to buy what you want </h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatum deserunt praesentium perferendis deleniti perspiciatis quo, facere earum aspernatur architecto hic id iure officia ullam recusandae inventore rem adipisci consectetur nulla.</p>
        </div>
    </div>
</main>