<?php session_start() ?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset='utf-8'>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="styles.css">
   <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
   <script src="script.js"></script>
   <title>Joao</title>
    <style>
    
    article {
        text-align: center;
    }
    p {
        max-width: 50%;
        margin: 20px auto;
    }

        .form {
            display: flex;
            align-items: center;
            flex-direction: column;
            height: 100vh;
        }

        h1 {
            margin-bottom: 100px;
        }

        .header-img {
            width: 100%;
            height: 400px;
            background: url('http://www.kodhus.com/freecourse-images/header-image.jpg');
            background-size: cover;
        }

        .hero-text {
            text-align: center;
            position: absolute;
            top: 30%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: white;
        }

        .hero-text button {
            border: none;
            outline: 0;
            display: inline-block;
            padding: 10px 25px;
            color: black;
            background-color: #ddd;
            text-align: center;
            cursor: pointer;
        }

        .hero-text button:hover {
            background-color: #555;
            color: white;
        }
    </style>
</head>
<body>
<?php require('navbar.php')?>
<?php require('header.php') ?>


</body>
</html>
<?php

include_once ('database.php');

if(isset($_GET['itemId'])) {

    $itemId = $_GET['itemId'];

    $connection = mysqli_connect(DB_SERVER, DB_USER, DB_PASSWORD);
    
    $db_found = mysqli_select_db($connection, DB_NAME);
    
    $query = "SELECT * FROM items i INNER JOIN author a ON i.author_id = a.author_id WHERE item_id = '$itemId' ";
    $result = mysqli_query($connection, $query);
    
    
    // ! RETRIEVE ALL THE BOOKS
    if(!isset($_GET['filter'])) {
        while($row = mysqli_fetch_assoc($result)) {
            echo "<article>";
            echo "<div>";
            echo "<h3 style='margin-top: 75px'>Item: </h3>";
            echo "<h3>" . $row['title'] . "</h3>";
            echo "<p> Release date: " . $row['release_date'];
            echo "<p> Price: " . $row['price'] . '$';
            echo "<p>" . $row['soldNum'] . " copies sold!";
            if(!empty($_SESSION['userId'])) {
                echo "<a href='#'><h5>Add to cart</h5></a>";
            }
            echo "<h3 style='margin-top: 75px'>Author: </h3>";
            echo "<p> " . $row['name'] . "<p>";
            echo "<p> Birth date: " . $row['year_birth'];
            if($row['gender'] == 'm') {
                echo "<p> Male </p>";
            } else {
                echo "<p> Female </p>";
            }
            echo "<p><strong>Biography:</strong></p>";
            echo "<p> " . $row['biography'] . "<p>";
            echo "</div>";
            echo "</article>";
        }
    
    }
}
